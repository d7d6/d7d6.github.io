# Kodi Repo
Kodi repository for Github for very stupid and simple kodi add-ons

# thanks and references
[jurialmunkey='s kodi github repository](https://github.com/jurialmunkey/repository.jurialmunkey/)