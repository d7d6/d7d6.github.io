# plugin.video.d7d6
Kodi video list from file

# references
this plugin is based on the [romanvm's kodi plugin video example](https://github.com/romanvm/plugin.video.example) and its [Dis90's fork](https://github.com/Dis90/plugin.video.example)